<!--这是子组件-->
<template>
    <div class="page-head">
      <span><img class='map' :src="MapImg" alt="">{{leftTitle}}</span>
      <span class='indexImg'><img :src="IndexImg" alt=""></span>
      <div class="right-head">
          <div  class="searchdiv ">
            <img :src="rightFirstImg" />
          </div>
          <div class="searchdiv second">
            <img :src="rightSecondImg" />
          </div>
      </div>
    </div>
</template>
<script>
export default {
    props:{//声明接收父组件数据
        leftTitle:{default:""},//左侧文字
        rightFirstImg:{default:""},//右侧第一张图片
        rightSecondImg:{default:""},//右侧第二张图片
        MapImg:{default:''},
        IndexImg:{default:''}
    },
    data(){
        return{}
    },
}
</script>
<style scoped>
  /* 1最外层的父元素 */
  .page-head{
      display:flex;
      position:fixed;/*固定位置*/
      z-index:999;
      width:100%;
      justify-content:space-between;
      align-items:center;
      background:#fff;
      color:#aaa;
      padding-left:7px;
      padding-right:7px;
      height:48px;
      font-size:18px;
      border-bottom:1px solid #ccc;
  } 
  /* 2右侧图片区域*/
  .right-head{
      display:flex;
  }
  /* 3图片*/
  .searchdiv{
      display:flex;
      align-items:center;
      height:48px;
  }
  .indexImg{
      display:flex;
      display:inline-block;
  }
  .indexImg>img{
     align-items:center;
     padding-left:20%; 
  }
  .searchdiv img{
      width:25px;
  }
  .map{
      width:20px;
  }
.second{
    margin-left:20px;
}
.second>img{
    margin-right:27px;
}
</style>
