<template>
  <div>
    <h1>这是cc</h1>
   <mt-button type="default">default</mt-button>
<mt-button type="primary" size='large'>primary</mt-button>
<mt-button type="danger">danger</mt-button>
  </div>
</template>