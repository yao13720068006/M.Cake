<template>
  <div class="top">
    <div class="text">
      <!--国家-->
      <div class="country">
        <img src="../assets/country.png">
      </div>
      <div class="img">
        <img src="../assets/wap.jpg">
      </div>






    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      
    }
  },
}
</script>
<style>
  /*国家*/
  .top .text .country{
    margin-left:9px;
  }
  /*图片*/
  .top .img img{
    width:360px;
    height:943px;
    margin-left:8px;
  }
</style>
