//router.js引入路由
import Vue from 'vue'
import Router from 'vue-router'
//自定义组件
import HelloContainer from "./components/HelloWorld.vue"
//1:引入Exam01.vue组件
import parents_index from "./components/Cake/common/index.vue"
import parents_chesi from "./components/Cake/common/chesi.vue"

Vue.use(Router)
//2:为Exam01.vue配置路径
export default new Router({
  routes: [
    {path:'/',component:HelloContainer},
    {path:'/index',component:parents_index},
    {path:'/cc',component:parents_chesi}

  ],
  mode:'history'
})
